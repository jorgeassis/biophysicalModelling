# geom_raster() checks input and coordinate system

    `hjust` must be a number

---

    `hjust` must be a number

---

    `vjust` must be a number

---

    `vjust` must be a number

---

    Problem while converting geom to grob.
    i Error occurred in the 1st layer.
    Caused by error in `draw_panel()`:
    ! `geom_raster()` only works with `coord_cartesian()`

