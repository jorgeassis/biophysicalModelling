# input checks work in compat functions

    Can only remove rownames from <data.frame> and <matrix> objects

---

    `x` must be a factor or character vector

---

    Must be a character vector, call, or formula

---

    `x` must be numeric

