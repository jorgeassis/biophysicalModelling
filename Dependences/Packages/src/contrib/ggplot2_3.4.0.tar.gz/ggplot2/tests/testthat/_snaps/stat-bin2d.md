# binwidth is respected

    Computation failed in `stat_bin2d()`
    Caused by error in `bin2d_breaks()`:
    ! `binwidth` must be a number

---

    Computation failed in `stat_bin2d()`
    Caused by error in `bin2d_breaks()`:
    ! `origin` must be a number

