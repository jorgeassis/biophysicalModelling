# autoplot throws helpful error on default

    Objects of class <integer> are not supported by autoplot.
    i have you loaded the required package?

