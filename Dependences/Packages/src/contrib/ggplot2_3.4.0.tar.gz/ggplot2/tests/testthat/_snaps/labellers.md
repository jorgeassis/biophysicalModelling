# resolve_labeller() provide meaningful errors

    Supply one of `rows` or `cols`

---

    Cannot supply both `rows` and `cols` to `facet_wrap()`

# labeller function catches overlap in names

    Conflict between `.rows` and `vs`

