# NA's result in warning from stat_bindot

    Removed 2 rows containing missing values (`stat_bindot()`).

# weight aesthetic is checked

    Computation failed in `stat_bindot()`
    Caused by error in `compute_group()`:
    ! Weights must be nonnegative integers.

---

    Computation failed in `stat_bindot()`
    Caused by error in `compute_group()`:
    ! Weights must be nonnegative integers.

