# collide() checks the input data

    Neither y nor ymax defined

---

    `test()` requires non-overlapping x intervals

