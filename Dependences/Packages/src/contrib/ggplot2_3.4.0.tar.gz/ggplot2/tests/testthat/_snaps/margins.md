# justify_grobs() checks input

    `grobs` must be an individual <grob> or list of <grob> objects.

