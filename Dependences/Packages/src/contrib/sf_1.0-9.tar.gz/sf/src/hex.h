Rcpp::List CPL_hex_to_raw(Rcpp::CharacterVector cx);
Rcpp::CharacterVector CPL_raw_to_hex(Rcpp::RawVector raw);
