pick_wrapper <- function(...) {
  # Wrapping `pick()` forces evaluation fallback
  pick(...)
}
