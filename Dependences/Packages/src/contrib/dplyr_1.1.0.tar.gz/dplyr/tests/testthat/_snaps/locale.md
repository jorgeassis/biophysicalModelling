# `dplyr_legacy_locale()` respects `dplyr.legacy_locale`

    Code
      dplyr_legacy_locale()
    Condition
      Error:
      ! Global option `dplyr.legacy_locale` must be a single `TRUE` or `FALSE`.

