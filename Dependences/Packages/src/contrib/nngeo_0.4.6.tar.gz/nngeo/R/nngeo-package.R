#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @useDynLib nngeo, .registration = TRUE
## usethis namespace: end
NULL
