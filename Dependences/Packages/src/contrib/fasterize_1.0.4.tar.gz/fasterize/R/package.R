
#' Fast sf-to-raster conversion
#'
#' Fast sf-to-raster conversion
#'
#' @docType package
#' @name fasterize
NULL

#' @useDynLib fasterize
#' @importFrom Rcpp sourceCpp
NULL
