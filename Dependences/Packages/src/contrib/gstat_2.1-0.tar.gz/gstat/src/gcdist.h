double gstat_gcdist(double lon1, double lon2, double lat1, double lat2);
