/* use same define in package's own header file */
#define SP_XPORT(x) RGEOS_ ## x
#include "sp_xports.c"

/* touch 110611 */
/* touch 111015 */ 
/* touch 111019 */ 
