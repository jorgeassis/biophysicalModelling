library(testthat)
library(h3jsr)

test_check("h3jsr")
