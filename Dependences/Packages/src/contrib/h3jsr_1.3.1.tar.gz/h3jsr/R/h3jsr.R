#' h3jsr: Access Uber's H3 library
#'
#' This package uses package \href{https://github.com/jeroen/v8}{V8} to access the
#' \href{https://github.com/uber/h3-js}{javascript bindings for Uber's H3 library}
#'
"_PACKAGE"
