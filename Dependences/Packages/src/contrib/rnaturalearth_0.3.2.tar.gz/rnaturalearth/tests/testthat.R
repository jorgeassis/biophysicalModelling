library(testthat)
library(rnaturalearth)

test_check("rnaturalearth")
